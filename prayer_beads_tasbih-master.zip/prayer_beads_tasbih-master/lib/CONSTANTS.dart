// ignore_for_file: file_names

const String kBeadsCount = 'beadsCount';
const String kRoundCount = 'RoundCount';
