[![style: lint](https://img.shields.io/badge/style-flutter__lints-4BC0F5.svg)](https://pub.dev/packages/flutter_lints)

# Prayer beads Flutter (Tasbih | Zikr)

A clone from [**pinkeshdarji/PrayerBeads**](https://github.com/pinkeshdarji/PrayerBeads)

<!-- ## App UI

| GIF                                                                                                                                        | Screenshot                                                                                                                                 |
| ------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------ |
| <img src="https://user-images.githubusercontent.com/60868965/94334737-4f988280-000a-11eb-92e8-161c9655be9b.gif" heigth="512" width="288"/> | <img src="https://user-images.githubusercontent.com/60868965/94332657-8fab3580-0009-11eb-852d-269a9838c1ba.jpg" heigth="512" width="288"/> | -->

## [RELEASES](https://github.com/iqfareez/prayer_beads_tasbih/releases)

1. For [Android](https://play.google.com/store/apps/details?id=com.iqfareez.prayer_beads)

2. [Web app](https://online-tasbeeh.web.app)

## SCREENSHOTS
![flutter_01 (Custom)](https://user-images.githubusercontent.com/60868965/152160335-688ee06d-7547-4ee9-a209-ff4792a24701.png)
![flutter_02 (Custom)](https://user-images.githubusercontent.com/60868965/152160343-5d11d5b1-66d0-42c7-b33d-d06929950bbf.png)
![ezgif com-gif-maker](https://user-images.githubusercontent.com/60868965/152160474-84a858c6-daeb-4d5d-9979-16988c3a65b3.gif)

## LICENSE

License came from the original repo. View license on `LICENSE`
